# Twitter Korean Tokenizer ElasticSearch Plugin

소스 & 패키징 방식 정리중

## Compatibility

| plugin verison | elasticsearch | twitter tokenizer |
| -------------- | ------------- | ----------------- |
| 0.0.2          | 5.2.2         | 4.4.4             |
| 0.0.1          | 5.2.1         | 4.4.4             |


```shell
curl -X PUT http://localhost:9200/test
```

```json

{
    "index" : {
        "analysis" : {
            "analyzer" : {
                "custom-analyzer" : {
                    "tokenizer" : "custom-tokenizer"
                }
            },
            "tokenizer": {
              "custom-tokenizer" : {
                "type": "twitter_korean_tokenizer",
                "enableNormalize": false,
                "enableStemmer": false
              }
            }
        }
    }
}

```

```shell
curl -X GET http://localhost:9200/test/_analyze?analyzer=custom-analyzer&text=간절히원하면우주가나서서도와준다
```

```json
{
	"tokens": [
		{
			"token": "간절히",
			"start_offset": 0,
			"end_offset": 3,
			"type": "Adjective",
			"position": 0
		},
		{
			"token": "원하면",
			"start_offset": 3,
			"end_offset": 6,
			"type": "Verb",
			"position": 1
		},
		{
			"token": "우",
			"start_offset": 6,
			"end_offset": 7,
			"type": "PreEomi",
			"position": 2
		},
		{
			"token": "주",
			"start_offset": 7,
			"end_offset": 8,
			"type": "PreEomi",
			"position": 3
		},
		{
			"token": "가",
			"start_offset": 8,
			"end_offset": 9,
			"type": "Eomi",
			"position": 4
		},
		{
			"token": "나서서",
			"start_offset": 9,
			"end_offset": 12,
			"type": "Verb",
			"position": 5
		},
		{
			"token": "도와준",
			"start_offset": 12,
			"end_offset": 15,
			"type": "Verb",
			"position": 6
		},
		{
			"token": "다",
			"start_offset": 15,
			"end_offset": 16,
			"type": "Eomi",
			"position": 7
		}
	]
}

```